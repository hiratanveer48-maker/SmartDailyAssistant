package com.mydailyassistant.app

import android.app.Application
import android.content.Context
import com.mydailyassistant.app.data.AppDatabase
import com.mydailyassistant.app.data.SettingsStore
import com.mydailyassistant.app.data.TaskRepository
import com.mydailyassistant.app.notifications.NotificationHelper
import com.mydailyassistant.app.notifications.ReminderScheduler

/** Simple manual dependency container shared by the UI and the broadcast receivers. */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val settings = SettingsStore(appContext)
    private val database = AppDatabase.build(appContext)
    val scheduler = ReminderScheduler(appContext, settings)
    val repository = TaskRepository(database.taskDao(), scheduler)
}

class DailyApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        NotificationHelper.createChannel(this)
    }
}
