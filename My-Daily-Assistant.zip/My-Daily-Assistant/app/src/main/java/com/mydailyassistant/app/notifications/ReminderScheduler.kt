package com.mydailyassistant.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.mydailyassistant.app.data.SettingsStore
import com.mydailyassistant.app.data.TaskEntity

/** Schedules, snoozes and cancels the alarms that trigger task reminders. */
class ReminderScheduler(
    private val context: Context,
    private val settings: SettingsStore
) {
    private val alarmManager =
        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    /** (Re)schedules the reminder of [task], or cancels it when no reminder is needed. */
    fun schedule(task: TaskEntity) {
        cancel(task.id)
        val current = settings.state.value
        if (!current.remindersEnabled || !task.reminderEnabled || task.isCompleted) return
        val triggerAt = task.dueAt - current.leadMinutes * 60_000L
        if (triggerAt <= System.currentTimeMillis()) return
        setAlarm(task.id, triggerAt)
    }

    fun snooze(taskId: Long, minutes: Int) {
        setAlarm(taskId, System.currentTimeMillis() + minutes * 60_000L)
    }

    fun cancel(taskId: Long) {
        alarmManager.cancel(pendingIntent(taskId))
    }

    private fun setAlarm(taskId: Long, triggerAt: Long) {
        val pendingIntent = pendingIntent(taskId)
        try {
            if (canScheduleExact()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            }
        } catch (e: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }
    }

    private fun pendingIntent(taskId: Long): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_REMIND
            data = Uri.parse("mydailyassistant://task/$taskId")
            putExtra(ReminderReceiver.EXTRA_TASK_ID, taskId)
        }
        return PendingIntent.getBroadcast(
            context,
            taskId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
