package com.mydailyassistant.app.data

import com.mydailyassistant.app.notifications.ReminderScheduler
import com.mydailyassistant.app.util.DateUtils
import kotlinx.coroutines.flow.Flow

class TaskRepository(
    private val dao: TaskDao,
    private val scheduler: ReminderScheduler
) {
    val tasks: Flow<List<TaskEntity>> = dao.observeAll()

    suspend fun get(id: Long): TaskEntity? = dao.getById(id)

    suspend fun getAll(): List<TaskEntity> = dao.getAll()

    /** Inserts or updates a task, (re)schedules its reminder and returns its id. */
    suspend fun save(task: TaskEntity): Long {
        val id = if (task.id == 0L) {
            dao.insert(task)
        } else {
            dao.update(task)
            task.id
        }
        scheduler.schedule(task.copy(id = id))
        return id
    }

    suspend fun delete(task: TaskEntity) {
        scheduler.cancel(task.id)
        dao.delete(task)
    }

    /**
     * Marks a task as completed / pending. Completing a repeating task keeps the finished
     * occurrence in the history and creates the next occurrence automatically.
     */
    suspend fun setCompleted(task: TaskEntity, completed: Boolean) {
        if (completed) {
            val now = System.currentTimeMillis()
            scheduler.cancel(task.id)
            if (task.repeat != RepeatType.NONE) {
                dao.update(
                    task.copy(
                        isCompleted = true,
                        completedAt = now,
                        repeat = RepeatType.NONE
                    )
                )
                val next = task.copy(
                    id = 0,
                    dueAt = DateUtils.nextOccurrence(task.dueAt, task.repeat, now),
                    isCompleted = false,
                    completedAt = null,
                    createdAt = now
                )
                val newId = dao.insert(next)
                scheduler.schedule(next.copy(id = newId))
            } else {
                dao.update(task.copy(isCompleted = true, completedAt = now))
            }
        } else {
            val reopened = task.copy(isCompleted = false, completedAt = null)
            dao.update(reopened)
            scheduler.schedule(reopened)
        }
    }

    suspend fun rescheduleAll() {
        dao.getAll().forEach { scheduler.schedule(it) }
    }

    suspend fun replaceAll(newTasks: List<TaskEntity>) {
        dao.getAll().forEach { scheduler.cancel(it.id) }
        dao.replaceAll(newTasks)
        dao.getAll().forEach { scheduler.schedule(it) }
    }

    suspend fun clearAll() {
        dao.getAll().forEach { scheduler.cancel(it.id) }
        dao.deleteAll()
    }
}
