package com.mydailyassistant.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.mydailyassistant.app.DailyApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Restores all reminder alarms after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }
        val container = (context.applicationContext as DailyApp).container
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                container.repository.rescheduleAll()
            } finally {
                pendingResult.finish()
            }
        }
    }
}
