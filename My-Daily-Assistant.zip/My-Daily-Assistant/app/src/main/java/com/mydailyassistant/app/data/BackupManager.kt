package com.mydailyassistant.app.data

import org.json.JSONArray
import org.json.JSONObject

/** Converts tasks and settings to and from a human-readable JSON backup file. */
object BackupManager {

    private const val APP_ID = "MyDailyAssistant"
    private const val FORMAT_VERSION = 1

    class BackupContents(val tasks: List<TaskEntity>, val settings: AppSettings?)

    fun toJson(tasks: List<TaskEntity>, settings: AppSettings): String {
        val root = JSONObject()
        root.put("app", APP_ID)
        root.put("version", FORMAT_VERSION)
        root.put("exportedAt", System.currentTimeMillis())

        val settingsJson = JSONObject()
        settingsJson.put("themeMode", settings.themeMode.name)
        settingsJson.put("remindersEnabled", settings.remindersEnabled)
        settingsJson.put("leadMinutes", settings.leadMinutes)
        settingsJson.put("snoozeMinutes", settings.snoozeMinutes)
        root.put("settings", settingsJson)

        val array = JSONArray()
        tasks.forEach { task ->
            val item = JSONObject()
            item.put("id", task.id)
            item.put("title", task.title)
            item.put("description", task.description)
            item.put("dueAt", task.dueAt)
            item.put("priority", task.priority.name)
            item.put("category", task.category.name)
            item.put("repeat", task.repeat.name)
            item.put("reminderEnabled", task.reminderEnabled)
            item.put("isCompleted", task.isCompleted)
            item.put("completedAt", task.completedAt ?: JSONObject.NULL)
            item.put("createdAt", task.createdAt)
            array.put(item)
        }
        root.put("tasks", array)
        return root.toString(2)
    }

    /** Parses a backup. Throws [IllegalArgumentException] when the file is not a valid backup. */
    fun parse(json: String): BackupContents {
        val root = try {
            JSONObject(json)
        } catch (e: Exception) {
            throw IllegalArgumentException("The selected file is not a valid backup.")
        }
        require(root.optString("app") == APP_ID) {
            "The selected file is not a My Daily Assistant backup."
        }
        val array = root.optJSONArray("tasks") ?: JSONArray()
        val tasks = ArrayList<TaskEntity>(array.length())
        for (index in 0 until array.length()) {
            val item = array.getJSONObject(index)
            tasks.add(
                TaskEntity(
                    id = item.optLong("id", 0L),
                    title = item.optString("title", "Untitled"),
                    description = item.optString("description", ""),
                    dueAt = item.optLong("dueAt", System.currentTimeMillis()),
                    priority = enumOrDefault(item.optString("priority"), Priority.MEDIUM),
                    category = enumOrDefault(item.optString("category"), Category.PERSONAL),
                    repeat = enumOrDefault(item.optString("repeat"), RepeatType.NONE),
                    reminderEnabled = item.optBoolean("reminderEnabled", true),
                    isCompleted = item.optBoolean("isCompleted", false),
                    completedAt = if (item.isNull("completedAt")) null else item.optLong("completedAt"),
                    createdAt = item.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }

        val settings = root.optJSONObject("settings")?.let { s ->
            AppSettings(
                themeMode = enumOrDefault(s.optString("themeMode"), ThemeMode.SYSTEM),
                remindersEnabled = s.optBoolean("remindersEnabled", true),
                leadMinutes = s.optInt("leadMinutes", 0),
                snoozeMinutes = s.optInt("snoozeMinutes", 10)
            )
        }
        return BackupContents(tasks, settings)
    }

    private inline fun <reified T : Enum<T>> enumOrDefault(name: String, default: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: default
}
