package com.mydailyassistant.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mydailyassistant.app.data.Category
import com.mydailyassistant.app.data.Priority
import com.mydailyassistant.app.data.TaskEntity
import com.mydailyassistant.app.data.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class StatusFilter(val label: String) {
    ALL("All"),
    PENDING("Pending"),
    COMPLETED("Completed")
}

enum class CalendarMode(val label: String) {
    DAY("Day"),
    WEEK("Week"),
    MONTH("Month")
}

data class TaskFilter(
    val query: String = "",
    val status: StatusFilter = StatusFilter.ALL,
    val category: Category? = null,
    val priority: Priority? = null
) {
    /** True when anything other than the plain "all tasks" view is selected. */
    val isActive: Boolean
        get() = query.isNotBlank() || status != StatusFilter.ALL || category != null || priority != null
}

class TasksViewModel(private val repository: TaskRepository) : ViewModel() {

    val allTasks: StateFlow<List<TaskEntity>> = repository.tasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _filter = MutableStateFlow(TaskFilter())
    val filter: StateFlow<TaskFilter> = _filter.asStateFlow()

    val filteredTasks: StateFlow<List<TaskEntity>> =
        combine(repository.tasks, _filter) { tasks, filter -> applyFilter(tasks, filter) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _selectedDate = MutableStateFlow(LocalDate.now())
    val selectedDate: StateFlow<LocalDate> = _selectedDate.asStateFlow()

    private val _calendarMode = MutableStateFlow(CalendarMode.MONTH)
    val calendarMode: StateFlow<CalendarMode> = _calendarMode.asStateFlow()

    fun setFilter(filter: TaskFilter) {
        _filter.value = filter
    }

    fun selectDate(date: LocalDate) {
        _selectedDate.value = date
    }

    fun setCalendarMode(mode: CalendarMode) {
        _calendarMode.value = mode
    }

    fun toggleCompleted(task: TaskEntity) {
        viewModelScope.launch { repository.setCompleted(task, !task.isCompleted) }
    }

    fun save(task: TaskEntity, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            repository.save(task)
            onSaved()
        }
    }

    fun delete(task: TaskEntity, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.delete(task)
            onDeleted()
        }
    }

    suspend fun getTask(id: Long): TaskEntity? = repository.get(id)

    private fun applyFilter(tasks: List<TaskEntity>, filter: TaskFilter): List<TaskEntity> {
        val query = filter.query.trim()
        val filtered = tasks.filter { task ->
            val matchesQuery = query.isEmpty() ||
                task.title.contains(query, ignoreCase = true) ||
                task.description.contains(query, ignoreCase = true) ||
                task.category.label.contains(query, ignoreCase = true)
            val matchesStatus = when (filter.status) {
                StatusFilter.ALL -> true
                StatusFilter.PENDING -> !task.isCompleted
                StatusFilter.COMPLETED -> task.isCompleted
            }
            val matchesCategory = filter.category == null || task.category == filter.category
            val matchesPriority = filter.priority == null || task.priority == filter.priority
            matchesQuery && matchesStatus && matchesCategory && matchesPriority
        }
        val (pending, completed) = filtered.partition { !it.isCompleted }
        return pending.sortedBy { it.dueAt } + completed.sortedByDescending { it.dueAt }
    }
}
