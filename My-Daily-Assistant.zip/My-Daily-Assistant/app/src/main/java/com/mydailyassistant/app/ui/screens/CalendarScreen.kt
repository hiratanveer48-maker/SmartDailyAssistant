@file:OptIn(ExperimentalMaterial3Api::class)

package com.mydailyassistant.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mydailyassistant.app.data.TaskEntity
import com.mydailyassistant.app.ui.components.EmptyState
import com.mydailyassistant.app.ui.components.SectionHeader
import com.mydailyassistant.app.ui.components.TaskCard
import com.mydailyassistant.app.ui.viewmodel.CalendarMode
import com.mydailyassistant.app.util.DateUtils
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private fun weekStart(date: LocalDate): LocalDate =
    date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

private fun shift(date: LocalDate, mode: CalendarMode, direction: Long): LocalDate = when (mode) {
    CalendarMode.DAY -> date.plusDays(direction)
    CalendarMode.WEEK -> date.plusWeeks(direction)
    CalendarMode.MONTH -> date.plusMonths(direction)
}

private fun title(date: LocalDate, mode: CalendarMode): String {
    val locale = Locale.getDefault()
    return when (mode) {
        CalendarMode.DAY -> date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", locale))
        CalendarMode.WEEK -> {
            val start = weekStart(date)
            val end = start.plusDays(6)
            start.format(DateTimeFormatter.ofPattern("d MMM", locale)) + " – " +
                end.format(DateTimeFormatter.ofPattern("d MMM yyyy", locale))
        }
        CalendarMode.MONTH -> date.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale))
    }
}

@Composable
fun CalendarScreen(
    tasks: List<TaskEntity>,
    selectedDate: LocalDate,
    mode: CalendarMode,
    onSelectDate: (LocalDate) -> Unit,
    onModeChange: (CalendarMode) -> Unit,
    onOpenTask: (Long) -> Unit,
    onToggle: (TaskEntity) -> Unit
) {
    val byDate = remember(tasks) { tasks.groupBy { DateUtils.toLocalDate(it.dueAt) } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "Calendar",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        item {
            TabRow(
                selectedTabIndex = mode.ordinal,
                containerColor = Color.Transparent
            ) {
                CalendarMode.values().forEach { entry ->
                    Tab(
                        selected = mode == entry,
                        onClick = { onModeChange(entry) },
                        text = { Text(entry.label) }
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onSelectDate(shift(selectedDate, mode, -1)) }) {
                    Icon(Icons.Filled.ChevronLeft, contentDescription = "Previous")
                }
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = title(selectedDate, mode),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center
                    )
                    TextButton(onClick = { onSelectDate(LocalDate.now()) }) {
                        Text("Today")
                    }
                }
                IconButton(onClick = { onSelectDate(shift(selectedDate, mode, 1)) }) {
                    Icon(Icons.Filled.ChevronRight, contentDescription = "Next")
                }
            }
        }

        when (mode) {
            CalendarMode.DAY -> {
                dayTaskItems(selectedDate, byDate[selectedDate].orEmpty(), onOpenTask, onToggle)
            }

            CalendarMode.WEEK -> {
                val start = weekStart(selectedDate)
                for (offset in 0..6) {
                    val date = start.plusDays(offset.toLong())
                    dayTaskItems(date, byDate[date].orEmpty(), onOpenTask, onToggle)
                }
            }

            CalendarMode.MONTH -> {
                item {
                    MonthGrid(
                        selected = selectedDate,
                        byDate = byDate,
                        onSelect = onSelectDate
                    )
                }
                dayTaskItems(selectedDate, byDate[selectedDate].orEmpty(), onOpenTask, onToggle)
            }
        }

        item(key = "bottom-spacer") {
            Spacer(Modifier.height(8.dp))
        }
    }
}

private fun LazyListScope.dayTaskItems(
    date: LocalDate,
    dayTasks: List<TaskEntity>,
    onOpenTask: (Long) -> Unit,
    onToggle: (TaskEntity) -> Unit
) {
    val sorted = dayTasks.sortedBy { it.dueAt }
    val label = if (date == LocalDate.now()) "Today • ${DateUtils.formatDate(date)}"
    else DateUtils.formatDate(date)

    item(key = "header-$date") {
        SectionHeader(text = label, count = sorted.size)
    }
    if (sorted.isEmpty()) {
        item(key = "empty-$date") {
            Text(
                text = "No tasks on this day",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    } else {
        items(sorted, key = { "task-${it.id}" }) { task ->
            TaskCard(
                task = task,
                onToggle = { onToggle(task) },
                onClick = { onOpenTask(task.id) }
            )
        }
    }
}

@Composable
private fun MonthGrid(
    selected: LocalDate,
    byDate: Map<LocalDate, List<TaskEntity>>,
    onSelect: (LocalDate) -> Unit
) {
    val first = selected.withDayOfMonth(1)
    val offset = first.dayOfWeek.value - 1
    val daysInMonth = selected.lengthOfMonth()
    val weeks = (offset + daysInMonth + 6) / 7
    val today = LocalDate.now()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("M", "T", "W", "T", "F", "S", "S").forEach { label ->
                    Text(
                        text = label,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            for (week in 0 until weeks) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (dayOfWeek in 0 until 7) {
                        val dayNumber = week * 7 + dayOfWeek - offset + 1
                        if (dayNumber in 1..daysInMonth) {
                            val date = first.withDayOfMonth(dayNumber)
                            DayCell(
                                date = date,
                                isSelected = date == selected,
                                isToday = date == today,
                                dayTasks = byDate[date].orEmpty(),
                                onClick = { onSelect(date) },
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    date: LocalDate,
    isSelected: Boolean,
    isToday: Boolean,
    dayTasks: List<TaskEntity>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val background = when {
        isSelected -> MaterialTheme.colorScheme.primary
        isToday -> MaterialTheme.colorScheme.primaryContainer
        else -> Color.Transparent
    }
    val dotColor = when {
        isSelected -> MaterialTheme.colorScheme.onPrimary
        dayTasks.any { !it.isCompleted } -> MaterialTheme.colorScheme.primary
        else -> Color(0xFF43A047)
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = date.dayOfMonth.toString(),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                else MaterialTheme.colorScheme.onSurface
            )
            if (dayTasks.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .padding(top = 2.dp)
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(dotColor)
                )
            } else {
                Spacer(Modifier.height(7.dp))
            }
        }
    }
}
