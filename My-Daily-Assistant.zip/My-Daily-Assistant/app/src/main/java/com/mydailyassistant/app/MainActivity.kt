package com.mydailyassistant.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.mydailyassistant.app.ui.MyDailyApp
import com.mydailyassistant.app.ui.theme.DailyTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val openTaskId = mutableStateOf<Long?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val container = (application as DailyApp).container

        val requestedId = intent?.getLongExtra(EXTRA_OPEN_TASK_ID, -1L) ?: -1L
        if (requestedId > 0) {
            openTaskId.value = requestedId
            intent?.removeExtra(EXTRA_OPEN_TASK_ID)
        }

        // Make sure every pending reminder has an alarm (also picks up permission changes).
        lifecycleScope.launch(Dispatchers.IO) {
            container.repository.rescheduleAll()
        }

        setContent {
            val settings by container.settings.state.collectAsStateWithLifecycle()
            DailyTheme(themeMode = settings.themeMode) {
                MyDailyApp(
                    container = container,
                    openTaskId = openTaskId.value,
                    onOpenTaskConsumed = { openTaskId.value = null }
                )
            }
        }
    }

    companion object {
        const val EXTRA_OPEN_TASK_ID = "extra_open_task_id"
    }
}
