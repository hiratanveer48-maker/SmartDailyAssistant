@file:OptIn(ExperimentalMaterial3Api::class)

package com.mydailyassistant.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mydailyassistant.app.AppContainer
import com.mydailyassistant.app.notifications.NotificationHelper
import com.mydailyassistant.app.ui.screens.CalendarScreen
import com.mydailyassistant.app.ui.screens.DashboardScreen
import com.mydailyassistant.app.ui.screens.SettingsScreen
import com.mydailyassistant.app.ui.screens.StatsScreen
import com.mydailyassistant.app.ui.screens.TaskEditScreen
import com.mydailyassistant.app.ui.screens.TasksScreen
import com.mydailyassistant.app.ui.viewmodel.AppViewModelFactory
import com.mydailyassistant.app.ui.viewmodel.SettingsViewModel
import com.mydailyassistant.app.ui.viewmodel.TasksViewModel

private object Routes {
    const val DASHBOARD = "dashboard"
    const val TASKS = "tasks"
    const val CALENDAR = "calendar"
    const val STATS = "stats"
    const val SETTINGS = "settings"
    const val EDIT = "edit/{taskId}?epochDay={epochDay}"

    fun edit(taskId: Long, epochDay: Long = -1L) = "edit/$taskId?epochDay=$epochDay"
}

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)

private val bottomItems = listOf(
    BottomItem(Routes.DASHBOARD, "Home", Icons.Filled.Home),
    BottomItem(Routes.TASKS, "Tasks", Icons.Filled.TaskAlt),
    BottomItem(Routes.CALENDAR, "Calendar", Icons.Filled.CalendarMonth),
    BottomItem(Routes.STATS, "Stats", Icons.Filled.BarChart),
    BottomItem(Routes.SETTINGS, "Settings", Icons.Filled.Settings)
)

@Composable
fun MyDailyApp(
    container: AppContainer,
    openTaskId: Long?,
    onOpenTaskConsumed: () -> Unit
) {
    val context = LocalContext.current
    val factory = remember(container) { AppViewModelFactory(container) }
    val tasksViewModel: TasksViewModel = viewModel(factory = factory)
    val settingsViewModel: SettingsViewModel = viewModel(factory = factory)

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val allTasks by tasksViewModel.allTasks.collectAsStateWithLifecycle()
    val filteredTasks by tasksViewModel.filteredTasks.collectAsStateWithLifecycle()
    val filter by tasksViewModel.filter.collectAsStateWithLifecycle()
    val selectedDate by tasksViewModel.selectedDate.collectAsStateWithLifecycle()
    val calendarMode by tasksViewModel.calendarMode.collectAsStateWithLifecycle()

    // Ask for the notification permission once on Android 13+.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { }
        LaunchedEffect(Unit) {
            if (!NotificationHelper.canNotify(context)) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val showBottomBar = currentRoute != Routes.EDIT
    val showFab = currentRoute == Routes.DASHBOARD ||
        currentRoute == Routes.TASKS ||
        currentRoute == Routes.CALENDAR

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (showFab) {
                FloatingActionButton(onClick = {
                    val epochDay =
                        if (currentRoute == Routes.CALENDAR) selectedDate.toEpochDay() else -1L
                    navController.navigate(Routes.edit(-1L, epochDay))
                }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add task")
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.DASHBOARD,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    tasks = allTasks,
                    onOpenTask = { navController.navigate(Routes.edit(it)) },
                    onToggle = { tasksViewModel.toggleCompleted(it) }
                )
            }
            composable(Routes.TASKS) {
                TasksScreen(
                    tasks = filteredTasks,
                    filter = filter,
                    onFilterChange = { tasksViewModel.setFilter(it) },
                    onOpenTask = { navController.navigate(Routes.edit(it)) },
                    onToggle = { tasksViewModel.toggleCompleted(it) }
                )
            }
            composable(Routes.CALENDAR) {
                CalendarScreen(
                    tasks = allTasks,
                    selectedDate = selectedDate,
                    mode = calendarMode,
                    onSelectDate = { tasksViewModel.selectDate(it) },
                    onModeChange = { tasksViewModel.setCalendarMode(it) },
                    onOpenTask = { navController.navigate(Routes.edit(it)) },
                    onToggle = { tasksViewModel.toggleCompleted(it) }
                )
            }
            composable(Routes.STATS) {
                StatsScreen(tasks = allTasks)
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(viewModel = settingsViewModel)
            }
            composable(
                route = Routes.EDIT,
                arguments = listOf(
                    navArgument("taskId") { type = NavType.LongType },
                    navArgument("epochDay") {
                        type = NavType.LongType
                        defaultValue = -1L
                    }
                )
            ) { entry ->
                val taskId = entry.arguments?.getLong("taskId") ?: -1L
                val epochDay = entry.arguments?.getLong("epochDay") ?: -1L
                TaskEditScreen(
                    taskId = taskId,
                    defaultEpochDay = epochDay,
                    viewModel = tasksViewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }

    // Open a task when the user taps a reminder notification.
    LaunchedEffect(openTaskId) {
        if (openTaskId != null) {
            navController.navigate(Routes.edit(openTaskId))
            onOpenTaskConsumed()
        }
    }
}
