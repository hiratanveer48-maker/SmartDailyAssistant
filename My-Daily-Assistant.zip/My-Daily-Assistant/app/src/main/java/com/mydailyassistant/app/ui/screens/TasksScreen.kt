@file:OptIn(ExperimentalMaterial3Api::class)

package com.mydailyassistant.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mydailyassistant.app.data.Category
import com.mydailyassistant.app.data.Priority
import com.mydailyassistant.app.data.TaskEntity
import com.mydailyassistant.app.ui.components.EmptyState
import com.mydailyassistant.app.ui.components.TaskCard
import com.mydailyassistant.app.ui.viewmodel.StatusFilter
import com.mydailyassistant.app.ui.viewmodel.TaskFilter

@Composable
fun TasksScreen(
    tasks: List<TaskEntity>,
    filter: TaskFilter,
    onFilterChange: (TaskFilter) -> Unit,
    onOpenTask: (Long) -> Unit,
    onToggle: (TaskEntity) -> Unit
) {
    var showFilters by remember { mutableStateOf(false) }
    val advancedActive = filter.category != null || filter.priority != null

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Tasks",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = filter.query,
                    onValueChange = { onFilterChange(filter.copy(query = it)) },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Search tasks") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = if (filter.query.isNotEmpty()) {
                        {
                            IconButton(onClick = { onFilterChange(filter.copy(query = "")) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear search")
                            }
                        }
                    } else null,
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )
                IconButton(onClick = { showFilters = !showFilters }) {
                    Icon(
                        imageVector = Icons.Filled.FilterList,
                        contentDescription = "Show filters",
                        tint = if (showFilters || advancedActive) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(StatusFilter.values().toList()) { status ->
                    FilterChip(
                        selected = filter.status == status,
                        onClick = { onFilterChange(filter.copy(status = status)) },
                        label = { Text(status.label) }
                    )
                }
            }

            if (showFilters) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Category.values().toList()) { category ->
                        FilterChip(
                            selected = filter.category == category,
                            onClick = {
                                onFilterChange(
                                    filter.copy(
                                        category = if (filter.category == category) null else category
                                    )
                                )
                            },
                            label = { Text(category.label) }
                        )
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Priority.values().toList()) { priority ->
                        FilterChip(
                            selected = filter.priority == priority,
                            onClick = {
                                onFilterChange(
                                    filter.copy(
                                        priority = if (filter.priority == priority) null else priority
                                    )
                                )
                            },
                            label = { Text("${priority.label} priority") }
                        )
                    }
                }
            }

            Text(
                text = if (tasks.size == 1) "1 task" else "${tasks.size} tasks",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(4.dp))

        if (tasks.isEmpty()) {
            EmptyState(
                icon = Icons.Filled.TaskAlt,
                title = if (filter.isActive) "No matching tasks" else "No tasks yet",
                message = if (filter.isActive) "Try a different search or filter."
                else "Tap the + button to create a task.",
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(tasks, key = { it.id }) { task ->
                    TaskCard(
                        task = task,
                        onToggle = { onToggle(task) },
                        onClick = { onOpenTask(task.id) }
                    )
                }
            }
        }
    }
}
