package com.mydailyassistant.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mydailyassistant.app.AppContainer
import com.mydailyassistant.app.data.AppSettings
import com.mydailyassistant.app.data.BackupManager
import com.mydailyassistant.app.data.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    private val settingsStore = container.settings
    private val repository = container.repository

    val settings: StateFlow<AppSettings> = settingsStore.state

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun consumeMessage() {
        _message.value = null
    }

    fun setThemeMode(mode: ThemeMode) {
        settingsStore.update { it.copy(themeMode = mode) }
    }

    fun setRemindersEnabled(enabled: Boolean) {
        settingsStore.update { it.copy(remindersEnabled = enabled) }
        viewModelScope.launch { repository.rescheduleAll() }
    }

    fun setLeadMinutes(minutes: Int) {
        settingsStore.update { it.copy(leadMinutes = minutes) }
        viewModelScope.launch { repository.rescheduleAll() }
    }

    fun setSnoozeMinutes(minutes: Int) {
        settingsStore.update { it.copy(snoozeMinutes = minutes) }
    }

    fun backupTo(uri: Uri) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val json = BackupManager.toJson(repository.getAll(), settingsStore.state.value)
                    val stream = container.appContext.contentResolver.openOutputStream(uri, "wt")
                        ?: throw IOException("Cannot open the selected file.")
                    stream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    "Backup saved successfully."
                } catch (e: Exception) {
                    "Backup failed: ${e.message ?: "unknown error"}"
                }
            }
            _message.value = result
        }
    }

    fun restoreFrom(uri: Uri) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val stream = container.appContext.contentResolver.openInputStream(uri)
                        ?: throw IOException("Cannot open the selected file.")
                    val json = stream.use { it.readBytes().toString(Charsets.UTF_8) }
                    val contents = BackupManager.parse(json)
                    repository.replaceAll(contents.tasks)
                    contents.settings?.let { restored -> settingsStore.update { restored } }
                    repository.rescheduleAll()
                    "Restored ${contents.tasks.size} tasks."
                } catch (e: Exception) {
                    "Restore failed: ${e.message ?: "unknown error"}"
                }
            }
            _message.value = result
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repository.clearAll() }
            _message.value = "All tasks deleted."
        }
    }
}
