package com.mydailyassistant.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Priority(val label: String, val weight: Int) {
    HIGH("High", 3),
    MEDIUM("Medium", 2),
    LOW("Low", 1)
}

enum class Category(val label: String) {
    STUDY("Study"),
    UNIVERSITY("University"),
    PERSONAL("Personal"),
    WORK("Work"),
    HEALTH("Health")
}

enum class RepeatType(val label: String) {
    NONE("Does not repeat"),
    DAILY("Daily"),
    WEEKLY("Weekly"),
    MONTHLY("Monthly")
}

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    /** Due date and time as epoch milliseconds. */
    val dueAt: Long,
    val priority: Priority = Priority.MEDIUM,
    val category: Category = Category.PERSONAL,
    val repeat: RepeatType = RepeatType.NONE,
    val reminderEnabled: Boolean = true,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
