package com.mydailyassistant.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode(val label: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark")
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val remindersEnabled: Boolean = true,
    /** Minutes before the due time at which the reminder fires (0 = at the due time). */
    val leadMinutes: Int = 0,
    /** Minutes a reminder is postponed when "Snooze" is tapped. */
    val snoozeMinutes: Int = 10
)

/** Small SharedPreferences-backed settings holder that exposes its value as a StateFlow. */
class SettingsStore(context: Context) {

    private val prefs =
        context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    private fun read(): AppSettings {
        val themeName = prefs.getString(KEY_THEME, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
        return AppSettings(
            themeMode = runCatching { ThemeMode.valueOf(themeName) }.getOrDefault(ThemeMode.SYSTEM),
            remindersEnabled = prefs.getBoolean(KEY_REMINDERS, true),
            leadMinutes = prefs.getInt(KEY_LEAD, 0),
            snoozeMinutes = prefs.getInt(KEY_SNOOZE, 10)
        )
    }

    fun update(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_state.value)
        prefs.edit()
            .putString(KEY_THEME, updated.themeMode.name)
            .putBoolean(KEY_REMINDERS, updated.remindersEnabled)
            .putInt(KEY_LEAD, updated.leadMinutes)
            .putInt(KEY_SNOOZE, updated.snoozeMinutes)
            .apply()
        _state.value = updated
    }

    private companion object {
        const val KEY_THEME = "theme_mode"
        const val KEY_REMINDERS = "reminders_enabled"
        const val KEY_LEAD = "lead_minutes"
        const val KEY_SNOOZE = "snooze_minutes"
    }
}
