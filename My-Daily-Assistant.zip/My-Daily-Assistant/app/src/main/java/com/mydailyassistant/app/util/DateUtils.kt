package com.mydailyassistant.app.util

import com.mydailyassistant.app.data.RepeatType
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

object DateUtils {

    private val zone: ZoneId get() = ZoneId.systemDefault()

    fun toLocalDateTime(millis: Long): LocalDateTime =
        LocalDateTime.ofInstant(Instant.ofEpochMilli(millis), zone)

    fun toLocalDate(millis: Long): LocalDate = toLocalDateTime(millis).toLocalDate()

    fun toMillis(value: LocalDateTime): Long = value.atZone(zone).toInstant().toEpochMilli()

    /**
     * Returns the first occurrence of a repeating task that is strictly after [after].
     * Monthly repetition clamps to the last day of shorter months.
     */
    fun nextOccurrence(
        dueAt: Long,
        repeat: RepeatType,
        after: Long = System.currentTimeMillis()
    ): Long {
        if (repeat == RepeatType.NONE) return dueAt
        var next = toLocalDateTime(dueAt)
        var guard = 0
        do {
            next = when (repeat) {
                RepeatType.DAILY -> next.plusDays(1)
                RepeatType.WEEKLY -> next.plusWeeks(1)
                RepeatType.MONTHLY -> next.plusMonths(1)
                RepeatType.NONE -> next
            }
            guard++
        } while (toMillis(next) <= after && guard < 5000)
        return toMillis(next)
    }

    fun formatDate(date: LocalDate): String =
        date.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault()))

    fun formatTime(time: LocalTime): String =
        time.format(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT))

    /** "Today, 9:00 AM", "Tomorrow, 6:30 PM" or "12 Nov, 3:00 PM". */
    fun formatDateTime(millis: Long): String {
        val dateTime = toLocalDateTime(millis)
        val date = dateTime.toLocalDate()
        val today = LocalDate.now()
        val dayText = when (date) {
            today -> "Today"
            today.plusDays(1) -> "Tomorrow"
            today.minusDays(1) -> "Yesterday"
            else -> date.format(DateTimeFormatter.ofPattern("d MMM", Locale.getDefault()))
        }
        return "$dayText, ${formatTime(dateTime.toLocalTime())}"
    }
}
