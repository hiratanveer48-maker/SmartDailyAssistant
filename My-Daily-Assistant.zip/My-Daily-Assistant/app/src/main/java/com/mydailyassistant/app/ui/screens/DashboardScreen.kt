@file:OptIn(ExperimentalMaterial3Api::class)

package com.mydailyassistant.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mydailyassistant.app.data.TaskEntity
import com.mydailyassistant.app.ui.components.EmptyState
import com.mydailyassistant.app.ui.components.SectionHeader
import com.mydailyassistant.app.ui.components.TaskCard
import com.mydailyassistant.app.util.DateUtils
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun DashboardScreen(
    tasks: List<TaskEntity>,
    onOpenTask: (Long) -> Unit,
    onToggle: (TaskEntity) -> Unit
) {
    val today = LocalDate.now()
    val todayTasks = tasks
        .filter { DateUtils.toLocalDate(it.dueAt) == today }
        .sortedBy { it.dueAt }
    val overdue = tasks
        .filter { !it.isCompleted && DateUtils.toLocalDate(it.dueAt).isBefore(today) }
        .sortedBy { it.dueAt }
    val upcoming = tasks
        .filter { !it.isCompleted && DateUtils.toLocalDate(it.dueAt).isAfter(today) }
        .sortedBy { it.dueAt }
        .take(5)

    val done = todayTasks.count { it.isCompleted }
    val total = todayTasks.size
    val progress = if (total == 0) 0f else done.toFloat() / total

    val hour = LocalTime.now().hour
    val greeting = when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else -> "Good evening"
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text(
                    text = greeting,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = DateUtils.formatDate(today),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            ProgressCard(done = done, total = total, progress = progress, overdue = overdue.size)
        }

        if (overdue.isNotEmpty()) {
            item { SectionHeader(text = "Overdue", count = overdue.size) }
            items(overdue, key = { "overdue-${it.id}" }) { task ->
                TaskCard(
                    task = task,
                    onToggle = { onToggle(task) },
                    onClick = { onOpenTask(task.id) }
                )
            }
        }

        item { SectionHeader(text = "Today", count = total) }
        if (todayTasks.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Filled.TaskAlt,
                    title = "Nothing planned for today",
                    message = "Tap the + button to add your first task."
                )
            }
        } else {
            items(todayTasks, key = { "today-${it.id}" }) { task ->
                TaskCard(
                    task = task,
                    onToggle = { onToggle(task) },
                    onClick = { onOpenTask(task.id) }
                )
            }
        }

        if (upcoming.isNotEmpty()) {
            item { SectionHeader(text = "Coming up", count = upcoming.size) }
            items(upcoming, key = { "upcoming-${it.id}" }) { task ->
                TaskCard(
                    task = task,
                    onToggle = { onToggle(task) },
                    onClick = { onOpenTask(task.id) }
                )
            }
        }
    }
}

@Composable
private fun ProgressCard(done: Int, total: Int, progress: Float, overdue: Int) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.horizontalGradient(listOf(Color(0xFF3949AB), Color(0xFF00897B)))
            )
            .padding(20.dp)
    ) {
        Column {
            Text(
                text = "Today's progress",
                style = MaterialTheme.typography.labelLarge,
                color = Color.White.copy(alpha = 0.85f)
            )
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "${(progress * 100).toInt()}%",
                    color = Color.White,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(50)),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.3f)
            )
            Spacer(Modifier.height(8.dp))
            val summary = if (total == 0) "No tasks scheduled today"
            else "$done of $total tasks completed"
            Text(
                text = if (overdue > 0) "$summary  •  $overdue overdue" else summary,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.9f)
            )
        }
    }
}
