package com.mydailyassistant.app.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.mydailyassistant.app.DailyApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Handles the alarm trigger and the "Snooze" / "Done" notification actions. */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        val action = intent.action
        if (taskId < 0 || action == null) return

        val container = (context.applicationContext as DailyApp).container
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = container.settings.state.value
                when (action) {
                    ACTION_REMIND -> {
                        val task = container.repository.get(taskId)
                        if (task != null && !task.isCompleted && settings.remindersEnabled) {
                            NotificationHelper.show(context, task, settings.snoozeMinutes)
                        }
                    }

                    ACTION_SNOOZE -> {
                        NotificationHelper.dismiss(context, taskId)
                        val task = container.repository.get(taskId)
                        if (task != null && !task.isCompleted) {
                            container.scheduler.snooze(taskId, settings.snoozeMinutes)
                        }
                    }

                    ACTION_DONE -> {
                        NotificationHelper.dismiss(context, taskId)
                        container.repository.get(taskId)?.let {
                            container.repository.setCompleted(it, true)
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_REMIND = "com.mydailyassistant.app.action.REMIND"
        const val ACTION_SNOOZE = "com.mydailyassistant.app.action.SNOOZE"
        const val ACTION_DONE = "com.mydailyassistant.app.action.DONE"
        const val EXTRA_TASK_ID = "extra_task_id"
    }
}
