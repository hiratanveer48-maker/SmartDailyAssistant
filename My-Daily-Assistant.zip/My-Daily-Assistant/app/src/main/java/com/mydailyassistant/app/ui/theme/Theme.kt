package com.mydailyassistant.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.mydailyassistant.app.data.ThemeMode

private val LightColors = lightColorScheme(
    primary = Color(0xFF3949AB),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE0E4FF),
    onPrimaryContainer = Color(0xFF0D1B6B),
    secondary = Color(0xFF00897B),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCCF2EC),
    onSecondaryContainer = Color(0xFF00201C),
    background = Color(0xFFF7F8FC),
    onBackground = Color(0xFF1B1D29),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B1D29),
    surfaceVariant = Color(0xFFE8EAF3),
    onSurfaceVariant = Color(0xFF454A5E),
    outline = Color(0xFF767B91),
    error = Color(0xFFB3261E),
    onError = Color(0xFFFFFFFF)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFB7BFFF),
    onPrimary = Color(0xFF1A2278),
    primaryContainer = Color(0xFF2E3A8C),
    onPrimaryContainer = Color(0xFFDDE0FF),
    secondary = Color(0xFF6FD8C8),
    onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF005047),
    onSecondaryContainer = Color(0xFFCCF2EC),
    background = Color(0xFF111320),
    onBackground = Color(0xFFE4E5F1),
    surface = Color(0xFF1A1C2C),
    onSurface = Color(0xFFE4E5F1),
    surfaceVariant = Color(0xFF2A2D40),
    onSurfaceVariant = Color(0xFFC3C6D9),
    outline = Color(0xFF8D90A5),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 34.sp
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.15.sp
    )
)

@Composable
fun DailyTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val colors = if (dark) DarkColors else LightColors

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colors.surface.toArgb()
            window.navigationBarColor = colors.surface.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    MaterialTheme(
        colorScheme = colors,
        typography = AppTypography,
        content = content
    )
}
