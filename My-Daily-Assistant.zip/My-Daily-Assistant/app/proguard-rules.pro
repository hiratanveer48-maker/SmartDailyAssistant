# ProGuard / R8 rules for release builds.
# The project ships with minification disabled, so no extra rules are required.
# Keep line numbers readable in crash reports:
-keepattributes SourceFile,LineNumberTable
