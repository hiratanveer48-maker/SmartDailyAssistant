# My Daily Assistant

An offline daily planner for Android built with **Kotlin**, **Jetpack Compose (Material 3)**, **MVVM** and **Room**.

| | |
|---|---|
| Package | `com.mydailyassistant.app` |
| Min SDK | 26 (Android 8.0) |
| Target / Compile SDK | 34 |
| Build tools | Android Gradle Plugin 8.5.2, Kotlin 1.9.24, Gradle 8.7 (wrapper), JDK 17 |

> **Build status:** this project was generated without access to an Android SDK, so it has **not been compiled or run by its author**. The first GitHub Actions run (or first Android Studio sync) is the real build test. If it reports an error, paste the error text to your assistant and it can be fixed quickly.

## Features

1. Dashboard with today's tasks, overdue tasks, upcoming tasks and a progress card
2. Add, edit and delete tasks
3. Due date and time pickers
4. High / Medium / Low priority
5. Study, University, Personal, Work and Health categories
6. Real Android notification reminders (exact alarms, survive reboots)
7. Snooze (and Done) buttons directly on the notification; snooze length is configurable
8. Daily, weekly and monthly recurring tasks (completing one automatically creates the next occurrence)
9. Day, week and month calendar views
10. Statistics: completion rate, pending / overdue counts, last-7-days chart, breakdown by category and priority
11. Search plus status, category and priority filters
12. Light, Dark and System themes
13. 100% offline Room database
14. Backup to and restore from a JSON file (stored wherever you choose)
15. Settings screen (theme, reminders, lead time, snooze length, notification permission, backup, delete all)

## Project structure

```
My-Daily-Assistant/
├── .github/workflows/build-apk.yml   ← builds the debug APK on GitHub
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── res/                      ← icons, themes, strings
│       └── java/com/mydailyassistant/app/
│           ├── data/                 ← Room entity, DAO, database, repository, backup, settings
│           ├── notifications/        ← alarm scheduler, receivers, notification builder
│           ├── ui/                   ← theme, components, screens, navigation, view models
│           ├── util/                 ← date helpers
│           ├── DailyApp.kt
│           └── MainActivity.kt
├── gradle/wrapper/                   ← Gradle wrapper (jar + properties)
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew
├── gradlew.bat
└── README.md
```

## 1. Upload the project to GitHub

GitHub's website cannot unpack a ZIP for you, so the ZIP must be **extracted first**.

1. Extract `My-Daily-Assistant.zip` (right-click → *Extract All* on Windows).
2. Open GitHub → **New repository** → name it (for example `My-Daily-Assistant`) → **Create repository**. Leave it empty (no README or .gitignore).
3. Choose one of these ways to upload:

**Option A – GitHub Desktop (easiest, keeps hidden folders)**
1. Install GitHub Desktop and sign in.
2. *File → Add local repository…* → choose the extracted `My-Daily-Assistant` folder → click *create a repository* if asked.
3. Commit all files, then **Publish repository**.

**Option B – Git command line**
```bash
cd path\to\My-Daily-Assistant
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/My-Daily-Assistant.git
git push -u origin main
```

**Option C – Browser drag-and-drop**
Open the empty repository → **uploading an existing file** → drag the **contents** of the extracted folder (not the folder itself) into the page, including the `.github` folder. Then **Commit changes**.
The files `build.gradle.kts`, `settings.gradle.kts`, `app/` and `.github/` must sit at the **root** of the repository.

## 2. Build the APK with GitHub Actions

1. Open your repository on GitHub → **Actions** tab.
2. The workflow **Build Debug APK** starts automatically after every push. To start it manually: select it → **Run workflow**.
3. Wait for the run to finish (the first run takes roughly 5–10 minutes because dependencies are downloaded).
4. Click the finished run → scroll to **Artifacts** → download **My-Daily-Assistant-debug-apk**.
5. Unzip the download – it contains `app-debug.apk`.
6. Copy the APK to your phone and open it. Allow *Install unknown apps* for your file manager or browser when Android asks.

If the run fails, open the failed step, copy the red error text and send it to your assistant for a fix.

## 3. Open the project later in Android Studio (Windows 10/11)

1. Install the latest **Android Studio** (it bundles a suitable JDK).
2. *File → Open…* → select the `My-Daily-Assistant` folder (the one that contains `settings.gradle.kts`).
3. Choose **Trust Project**. Android Studio runs a Gradle sync and downloads the Gradle 8.7 distribution and all libraries (internet needed once).
4. If prompted, install **Android SDK Platform 34** (*Tools → SDK Manager*).
5. Run on a phone (USB debugging on) or an emulator with the green ▶ button.
6. To create an APK locally: *Build → Build Bundle(s) / APK(s) → Build APK(s)*, or in a terminal:
   ```
   gradlew.bat assembleDebug
   ```
   The file appears at `app\build\outputs\apk\debug\app-debug.apk`.

To continue development with GitHub: *Git → Clone* (or use the repository you already have) and push changes – every push rebuilds the APK.

## Notes on reminders

* Reminders use exact alarms. The app declares `USE_EXACT_ALARM` (Android 13+) and `SCHEDULE_EXACT_ALARM` (Android 12), so no extra permission screen is normally needed.
* On Android 13+ the app asks for the notification permission on first launch. If you decline, *Settings → Reminders* shows the status and a shortcut to the system notification settings.
* Alarms are restored after a reboot or app update. Some phone brands (Xiaomi, Oppo, Vivo, Huawei, Samsung "sleeping apps") kill background apps aggressively – if reminders arrive late, exclude My Daily Assistant from battery optimisation.
* A repeating task shows only its **next** occurrence in lists and the calendar; when you complete it, the finished occurrence stays in your history/statistics and the next one is created.

## Backup file

*Settings → Backup* writes a readable `.json` file wherever you choose (internal storage, Google Drive, USB …). *Restore* replaces the current tasks (and settings) with the contents of a backup file.
